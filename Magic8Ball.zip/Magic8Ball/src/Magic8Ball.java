import java.util.Scanner;

public class Magic8Ball {
    public static void main (String[] args){
    //Prompt the user to ask yes or no question
    System.out.println(" Go ahead, ask me any yes or no question : ");
    //Create the scanner object to get input
    Scanner scanner = new Scanner(System.in);
    //Get the input from user
    String userQuestion = scanner.nextLine();
    //Prompt the user to enter a number 1-8
    System.out.println(" Enter a number 1-8 : \n");
    int number = scanner.nextInt();

    if(number == 1) {
        System.out.println("Great question, but no. ");
    } else if(number == 2) {
        System.out.println("No. ");
    } else if(number == 3) {
        System.out.println("I don't see why not. ");
    }else if(number == 4) {
        System.out.println("Maybe. ");
    }else if(number == 5) {
        System.out.println("Yes. ");
    }else if(number == 6) {
        System.out.println("Can a fish walk? ");
    }else if(number == 7) {
        System.out.println("Yes, Great question!");
    }else if(number == 8) {
        System.out.println("Does a lion have a mane? ");
    }
        }//end main
}//end class
